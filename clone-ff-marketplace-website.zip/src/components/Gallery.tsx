"use client";

import { useState } from "react";

export default function Gallery({ images, level }: { images: string[]; level: number }) {
  const [active, setActive] = useState(0);
  const main = images[active] ?? images[0];

  return (
    <div>
      <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-black/40">
        {main ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={main}
            alt={`Free Fire account LV ${level} screenshot`}
            className="aspect-video w-full object-contain"
          />
        ) : null}
        <span className="absolute left-3 top-3 rounded-md bg-black/70 px-3 py-1 text-sm font-bold text-gold">
          LV {level}
        </span>
      </div>
      <div className="no-scrollbar mt-3 flex gap-2 overflow-x-auto">
        {images.map((img, i) => (
          <button
            key={img}
            onClick={() => setActive(i)}
            className={`h-16 w-24 flex-shrink-0 overflow-hidden rounded-lg border ${
              i === active ? "border-[#ffba00]" : "border-white/10"
            }`}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={img} alt={`thumb ${i + 1}`} className="h-full w-full object-cover" />
          </button>
        ))}
      </div>
    </div>
  );
}
