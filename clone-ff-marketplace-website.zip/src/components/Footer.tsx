import Link from "next/link";

export default function Footer() {
  return (
    <footer className="mt-20 border-t border-white/10 bg-[#0b0e16]">
      <div className="container-ff grid gap-10 py-12 md:grid-cols-4">
        <div className="md:col-span-2">
          <div className="flex items-center gap-2">
            <span className="grid h-9 w-9 place-items-center rounded-lg bg-gradient-to-b from-[#ffc600] to-[#ffba00] text-[#1a1203] font-black">
              FF
            </span>
            <span className="text-lg font-extrabold">
              FF ID <span className="text-gold">Bazaar</span>
            </span>
          </div>
          <p className="mt-4 max-w-md text-sm text-slate-400">
            FF ID Bazaar is India&apos;s trusted marketplace to buy and sell Free Fire
            accounts. Verified sellers, admin-protected transfers and a secure payment
            process — the safest way to buy a Free Fire account anywhere.
          </p>
        </div>
        <div>
          <h4 className="mb-3 text-sm font-bold uppercase tracking-wide text-slate-200">
            Quick Links
          </h4>
          <ul className="space-y-2 text-sm text-slate-400">
            <li>
              <Link href="/account-list" className="hover:text-gold">
                Buy Account
              </Link>
            </li>
            <li>
              <Link href="/#how-we-work" className="hover:text-gold">
                How We Work
              </Link>
            </li>
            <li>
              <Link href="/#faq-section" className="hover:text-gold">
                FAQ
              </Link>
            </li>
          </ul>
        </div>
        <div>
          <h4 className="mb-3 text-sm font-bold uppercase tracking-wide text-slate-200">
            Legal
          </h4>
          <ul className="space-y-2 text-sm text-slate-400">
            <li>
              <Link href="/privacy-policy" className="hover:text-gold">
                Privacy Policy
              </Link>
            </li>
            <li>
              <Link href="/refund-policy" className="hover:text-gold">
                Refund Policy
              </Link>
            </li>
            <li>
              <Link href="/terms" className="hover:text-gold">
                Terms &amp; Conditions
              </Link>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10 py-5 text-center text-xs text-slate-500">
        © {new Date().getFullYear()} FF ID Bazaar. All rights reserved.
      </div>
    </footer>
  );
}
