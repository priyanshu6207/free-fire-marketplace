import Link from "next/link";

function Logo() {
  return (
    <Link href="/" className="flex items-center gap-2">
      <span className="grid h-9 w-9 place-items-center rounded-lg bg-gradient-to-b from-[#ffc600] to-[#ffba00] text-[#1a1203] font-black">
        FF
      </span>
      <span className="text-lg font-extrabold tracking-tight">
        FF ID <span className="text-gold">Bazaar</span>
      </span>
    </Link>
  );
}

export default function Navbar() {
  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-[#0b0e16]/85 backdrop-blur">
      <nav className="container-ff flex h-16 items-center justify-between gap-4">
        <Logo />
        <div className="hidden items-center gap-6 text-sm font-medium text-slate-200 md:flex">
          <Link href="/" className="hover:text-gold">
            Home
          </Link>
          <Link href="/account-list" className="hover:text-gold">
            Buy Account
          </Link>
          <Link href="/#how-we-work" className="hover:text-gold">
            How We Work
          </Link>
          <Link href="/#faq-section" className="hover:text-gold">
            FAQ
          </Link>
        </div>
        <div className="flex items-center gap-2">
          <Link
            href="/account-list"
            className="hidden rounded-full border border-white/15 px-4 py-2 text-sm font-semibold text-slate-100 hover:border-gold hover:text-gold sm:inline-block"
          >
            Login
          </Link>
          <Link href="/account-list" className="btn-gold px-4 py-2 text-sm">
            Sell Account
          </Link>
        </div>
      </nav>
    </header>
  );
}
