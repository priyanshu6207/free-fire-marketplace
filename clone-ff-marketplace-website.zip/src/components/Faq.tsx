const faqs = [
  {
    q: "Is it safe to buy a Free Fire account on FF ID Bazaar?",
    a: "Yes. Every deal on FF ID Bazaar is handled under admin supervision. Your payment is locked first and account details are only released once everything is verified. This keeps both buyers and sellers protected.",
  },
  {
    q: "How do I buy an account?",
    a: "Browse the listings, open an account you like, and click Pay Now. Scan the UPI QR code to complete the payment to the admin. Once payment is confirmed, the seller securely shares the account details.",
  },
  {
    q: "What payment methods are accepted?",
    a: "Payments are made securely via UPI. Simply scan the QR code shown on the payment page using any UPI app such as Paytm, PhonePe, Google Pay or BHIM.",
  },
  {
    q: "What if there is an issue with the account after purchase?",
    a: "If the seller does not provide the account details within 10 hours, you receive a full refund. There is also a 15-day secure window — if any issue occurs, contact the admin right away.",
  },
  {
    q: "Can I sell my Free Fire account here?",
    a: "Absolutely. Create a listing with accurate details and screenshots. Once approved, interested buyers can contact you and the admin mediates the entire transaction safely.",
  },
];

export default function Faq() {
  return (
    <section id="faq-section" className="container-ff py-14">
      <h2 className="text-center text-2xl font-black md:text-3xl">
        Frequently Asked Questions
      </h2>
      <div className="mx-auto mt-2 h-1 w-20 rounded bg-[#ffba00]" />
      <div className="mx-auto mt-10 max-w-3xl space-y-3">
        {faqs.map((f) => (
          <details key={f.q} className="card-ff group p-5">
            <summary className="flex cursor-pointer list-none items-center justify-between font-semibold">
              <span>{f.q}</span>
              <span className="text-gold transition group-open:rotate-45">+</span>
            </summary>
            <p className="mt-3 text-sm text-slate-400">{f.a}</p>
          </details>
        ))}
      </div>
    </section>
  );
}
