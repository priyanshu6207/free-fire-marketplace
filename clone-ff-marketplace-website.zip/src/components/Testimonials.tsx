const testimonials = [
  {
    rating: "4.8",
    text: "Sold my Level 75 account in just 3 days. Admin was very professional and the buyer was genuine. Got full payment without any issues. Best platform for FF account trading!",
    initials: "NB",
    name: "Nathan Brooks",
    role: "Seller",
  },
  {
    rating: "4.5",
    text: "Compared to other trading sites, this platform actually has a real admin watching every transaction. Bought a Grandmaster account and everything was exactly as listed. Felt 100% safe!",
    initials: "TN",
    name: "Thanh Nguyen",
    role: "Buyer",
  },
  {
    rating: "4.7",
    text: "Sold my rare skin account here and the experience was flawless. Listing was approved in hours and I had a buyer the next day. Admin support is what makes this platform stand out!",
    initials: "TY",
    name: "Tanaka Yuki",
    role: "Seller",
  },
  {
    rating: "4.6",
    text: "Bought a Heroic account with rare skins and the whole process was completely safe. Admin verified everything before transfer. 100% trustworthy platform. Will buy again!",
    initials: "PM",
    name: "Priya Mehta",
    role: "Buyer",
  },
  {
    rating: "4.9",
    text: "Great experience selling my Diamond account here. The admin verified my listing quickly and I got a buyer the same day. Payment was confirmed fast and the process was hassle-free!",
    initials: "AH",
    name: "Ali Hassan",
    role: "Seller",
  },
  {
    rating: "4.8",
    text: "Listed my account and got a serious buyer within 2 days. The chat system made negotiation super easy. Admin handled everything professionally. Got ₹4,500 for my Level 55 account!",
    initials: "AS",
    name: "Arjun Singh",
    role: "Seller",
  },
];

export default function Testimonials() {
  return (
    <section className="container-ff py-14">
      <h2 className="text-center text-2xl font-black md:text-3xl">Testimonials</h2>
      <div className="mx-auto mt-2 h-1 w-20 rounded bg-[#ffba00]" />
      <div className="mt-10 grid gap-5 md:grid-cols-3">
        {testimonials.map((t) => (
          <div key={t.name} className="card-ff p-6">
            <div className="flex items-center justify-between">
              <span className="text-4xl leading-none text-gold">&ldquo;</span>
              <span className="rounded-full bg-[#ffba00]/15 px-2 py-0.5 text-sm font-bold text-gold">
                {t.rating} ★
              </span>
            </div>
            <p className="mt-2 text-sm text-slate-300">{t.text}</p>
            <div className="mt-5 flex items-center gap-3">
              <span className="grid h-10 w-10 place-items-center rounded-full bg-[#ffba00] font-bold text-[#1a1203]">
                {t.initials}
              </span>
              <div>
                <div className="text-sm font-semibold">{t.name}</div>
                <div className="text-xs text-slate-400">{t.role}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
