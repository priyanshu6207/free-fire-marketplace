import Link from "next/link";
import type { Account } from "@/db/schema";
import { formatINR } from "@/lib/accounts";

export default function AccountCard({ account }: { account: Account }) {
  const cover = account.images[0];
  return (
    <Link href={`/account/${account.id}`} className="card-ff block">
      <div className="relative aspect-[4/3] w-full bg-black/40">
        {cover ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={cover}
            alt={`Free Fire account LV ${account.level}`}
            className="h-full w-full object-cover"
            loading="lazy"
          />
        ) : null}
        <span className="absolute left-2 top-2 rounded-md bg-black/70 px-2 py-1 text-xs font-bold text-gold">
          LV {account.level}
        </span>
        <span className="absolute right-2 top-2 rounded-md bg-[#ffba00] px-2 py-1 text-xs font-extrabold text-[#1a1203]">
          {formatINR(account.price)}
        </span>
      </div>
      <div className="p-3">
        <div className="flex items-center justify-between text-xs text-slate-400">
          <span>Acc ID {account.accId}</span>
          <span className="rounded bg-white/5 px-1.5 py-0.5 font-semibold text-slate-200">
            {account.country}
          </span>
        </div>
        <div className="mt-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            {account.sellerAvatar ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={account.sellerAvatar}
                alt={account.sellerName}
                className="h-6 w-6 rounded-full object-cover"
              />
            ) : (
              <span className="grid h-6 w-6 place-items-center rounded-full bg-[#ffba00]/20 text-[10px] font-bold text-gold">
                {account.sellerName.slice(0, 1).toUpperCase()}
              </span>
            )}
            <span className="max-w-[90px] truncate text-xs font-medium text-slate-200">
              {account.sellerName}
            </span>
          </div>
          <span className="text-xs text-slate-400">
            ⭐ {account.sellerRating} ({account.sellerReviews})
          </span>
        </div>
      </div>
    </Link>
  );
}
