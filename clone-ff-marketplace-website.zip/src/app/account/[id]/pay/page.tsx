import Link from "next/link";
import { notFound } from "next/navigation";
import { getAccount, formatINR } from "@/lib/accounts";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Complete Payment | FF ID Bazaar",
};

export default async function PayPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const accountId = Number(id);
  if (!Number.isFinite(accountId)) notFound();

  const account = await getAccount(accountId);
  if (!account) notFound();

  return (
    <main className="container-ff py-10">
      <div className="mx-auto max-w-xl">
        <nav className="mb-5 text-sm text-slate-400">
          <Link href={`/account/${account.id}`} className="hover:text-gold">
            ← Back to account
          </Link>
        </nav>

        <div className="card-ff p-6 text-center">
          <h1 className="text-2xl font-black">Complete Your Payment</h1>
          <p className="mt-1 text-sm text-slate-400">
            Acc ID {account.accId} · LV {account.level}
          </p>

          <div className="mt-5 inline-flex items-center gap-2 rounded-xl bg-[#ffba00]/10 px-5 py-3">
            <span className="text-sm text-slate-300">Amount to pay</span>
            <span className="text-2xl font-black text-gold">
              {formatINR(account.price)}
            </span>
          </div>

          {/* Paytm UPI QR card */}
          <div className="mx-auto mt-7 max-w-xs rounded-3xl bg-white p-5 shadow-2xl">
            <div className="flex flex-col items-center">
              <div className="grid h-16 w-16 place-items-center overflow-hidden rounded-full bg-gradient-to-br from-slate-700 to-slate-900 text-xl font-black text-white">
                P
              </div>
              <div className="mt-2 flex items-center gap-1">
                <span className="text-sm font-extrabold text-slate-900">
                  PRIYANSHU KUMAR SINGH
                </span>
                <span className="text-[#1e9bf0]">✔</span>
              </div>
            </div>

            <div className="mt-4 rounded-2xl bg-[#012b72] p-3">
              <div className="rounded-xl bg-white p-4">
                <div className="mb-3 flex items-center justify-center gap-1 text-sm font-extrabold">
                  <span className="text-[#012b72]">pay</span>
                  <span className="text-[#00baf2]">tm</span>
                  <span className="text-rose-500">♥</span>
                  <span className="text-[#012b72]">UPI</span>
                </div>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src="/images/paytm-qr.png"
                  alt="Paytm UPI QR code"
                  className="mx-auto h-56 w-56"
                />
                <div className="mt-3 text-center text-sm font-semibold text-slate-800">
                  🇮🇳 rohitsekhawat@ptyes
                </div>
              </div>
            </div>

            <div className="mt-3 text-center text-xs font-medium text-slate-500">
              Scan with any UPI app · Paytm · PhonePe · GPay · BHIM
            </div>
          </div>

          <div className="mt-7 rounded-xl bg-white/5 p-4 text-left text-sm text-slate-300">
            <p className="font-bold text-gold">How to pay</p>
            <ol className="mt-2 list-decimal space-y-1 pl-5">
              <li>Open any UPI app (Paytm / PhonePe / GPay / BHIM).</li>
              <li>Scan the QR code above and enter {formatINR(account.price)}.</li>
              <li>Complete the payment to the admin (PRIYANSHU KUMAR SINGH).</li>
              <li>
                After payment, the account details are securely shared under admin
                supervision.
              </li>
            </ol>
            <p className="mt-3 text-xs text-slate-500">
              🔒 Payment is locked first. If account details are not provided within 10
              hours, you receive a full refund.
            </p>
          </div>

          <a
            href={`upi://pay?pa=rohitsekhawat@ptyes&pn=PRIYANSHU%20KUMAR%20SINGH&am=${account.price}&cu=INR`}
            className="btn-gold mt-6 inline-block px-8 py-3 text-sm"
          >
            Pay {formatINR(account.price)} via UPI App
          </a>
        </div>
      </div>
    </main>
  );
}
