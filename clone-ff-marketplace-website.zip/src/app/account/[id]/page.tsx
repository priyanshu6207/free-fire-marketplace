import Link from "next/link";
import { notFound } from "next/navigation";
import Gallery from "@/components/Gallery";
import AccountCard from "@/components/AccountCard";
import { getAccount, getRelatedAccounts, formatINR } from "@/lib/accounts";

export const dynamic = "force-dynamic";

export default async function AccountDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const accountId = Number(id);
  if (!Number.isFinite(accountId)) notFound();

  const account = await getAccount(accountId);
  if (!account) notFound();

  const related = await getRelatedAccounts(accountId, 8);

  const specs = [
    { label: "Account Level", value: `LV ${account.level}` },
    { label: "Login With", value: account.loginWith },
    { label: "Server", value: account.server },
    { label: "Account ID", value: account.accId },
  ];

  return (
    <main className="container-ff py-8">
      <nav className="mb-5 text-sm text-slate-400">
        <Link href="/" className="hover:text-gold">
          Home
        </Link>{" "}
        /{" "}
        <Link href="/account-list" className="hover:text-gold">
          Buy Account
        </Link>{" "}
        / <span className="text-slate-200">Acc ID {account.accId}</span>
      </nav>

      <div className="grid gap-8 lg:grid-cols-[1.4fr_1fr]">
        <Gallery images={account.images} level={account.level} />

        <aside className="card-ff h-fit p-6">
          <div className="flex items-center justify-between">
            <span className="rounded-md bg-black/60 px-3 py-1 text-sm font-bold text-gold">
              LV {account.level}
            </span>
            <span className="text-3xl font-black text-gold">
              {formatINR(account.price)}
            </span>
          </div>

          <dl className="mt-6 divide-y divide-white/10">
            {specs.map((s) => (
              <div key={s.label} className="flex items-center justify-between py-3 text-sm">
                <dt className="text-slate-400">{s.label}</dt>
                <dd className="font-semibold text-slate-100">{s.value}</dd>
              </div>
            ))}
          </dl>

          <div className="mt-5 flex items-center gap-3 rounded-xl bg-white/5 p-3">
            {account.sellerAvatar ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={account.sellerAvatar}
                alt={account.sellerName}
                className="h-10 w-10 rounded-full object-cover"
              />
            ) : (
              <span className="grid h-10 w-10 place-items-center rounded-full bg-[#ffba00]/20 font-bold text-gold">
                {account.sellerName.slice(0, 1).toUpperCase()}
              </span>
            )}
            <div>
              <div className="text-sm font-semibold">{account.sellerName}</div>
              <div className="text-xs text-slate-400">
                ⭐ {account.sellerRating} ({account.sellerReviews}) · Member since{" "}
                {account.memberSince}
              </div>
            </div>
          </div>

          <Link
            href={`/account/${account.id}/pay`}
            className="btn-gold mt-6 block w-full py-3 text-center text-base"
          >
            Pay Now
          </Link>
          <p className="mt-3 text-center text-xs text-slate-500">
            🔒 Admin-protected · Payment locked first · 15-day secure transfer window
          </p>
        </aside>
      </div>

      {related.length > 0 && (
        <section className="mt-14">
          <h2 className="mb-5 text-xl font-black">More Accounts You May Like</h2>
          <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
            {related.map((acc) => (
              <AccountCard key={acc.id} account={acc} />
            ))}
          </div>
        </section>
      )}
    </main>
  );
}
