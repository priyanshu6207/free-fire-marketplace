import AccountCard from "@/components/AccountCard";
import { getAllAccounts } from "@/lib/accounts";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Buy Free Fire Account — Browse All Listings | FF ID Bazaar",
};

export default async function AccountListPage() {
  const accounts = await getAllAccounts();

  return (
    <main className="container-ff py-10">
      <div className="rounded-2xl bg-gradient-to-br from-[#171b27] to-[#1e2333] p-8 text-center gold-ring">
        <span className="inline-block rounded-full border border-[#ffba00]/40 bg-[#ffba00]/10 px-4 py-1 text-xs font-bold uppercase tracking-wider text-gold">
          Account Marketplace
        </span>
        <h1 className="mt-4 text-3xl font-black md:text-4xl">
          Buy &amp; Sell Free Fire Accounts Safely
        </h1>
        <p className="mt-3 text-sm text-slate-300">
          Buy and sell Free Fire accounts safely and securely on FF ID Bazaar.
        </p>
      </div>

      <div className="mt-8 mb-4 flex items-center justify-between">
        <h2 className="text-xl font-black">Search Results</h2>
        <span className="rounded-full bg-[#ffba00]/15 px-3 py-1 text-sm font-bold text-gold">
          {accounts.length} accounts
        </span>
      </div>

      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        {accounts.map((acc) => (
          <AccountCard key={acc.id} account={acc} />
        ))}
      </div>
    </main>
  );
}
