export const metadata = { title: "Privacy Policy | FF ID Bazaar" };

export default function PrivacyPolicy() {
  return (
    <main className="container-ff py-12">
      <h1 className="text-3xl font-black">Privacy Policy</h1>
      <div className="mt-6 space-y-4 text-sm leading-relaxed text-slate-300">
        <p>
          FF ID Bazaar respects your privacy. We only collect the information needed to
          operate the marketplace and process account transfers securely under admin
          supervision.
        </p>
        <p>
          We never sell your personal data. Payment details are handled through secure UPI
          and are not stored on our servers.
        </p>
        <p>
          By using FF ID Bazaar you agree to the collection and use of information in
          accordance with this policy.
        </p>
      </div>
    </main>
  );
}
