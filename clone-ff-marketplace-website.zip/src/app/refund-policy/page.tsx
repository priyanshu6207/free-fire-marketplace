export const metadata = { title: "Refund Policy | FF ID Bazaar" };

export default function RefundPolicy() {
  return (
    <main className="container-ff py-12">
      <h1 className="text-3xl font-black">Refund Policy</h1>
      <div className="mt-6 space-y-4 text-sm leading-relaxed text-slate-300">
        <p>
          At FF ID Bazaar every payment is locked first and held under admin supervision.
          If the seller does not provide the account details within 10 hours, the buyer
          receives a full refund.
        </p>
        <p>
          There is a 15-day secure transfer window. If any issue occurs within this period,
          contact the admin immediately and the matter will be resolved fairly.
        </p>
      </div>
    </main>
  );
}
