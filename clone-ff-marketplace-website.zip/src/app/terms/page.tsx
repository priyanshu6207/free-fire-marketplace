export const metadata = { title: "Terms & Conditions | FF ID Bazaar" };

export default function Terms() {
  return (
    <main className="container-ff py-12">
      <h1 className="text-3xl font-black">Terms &amp; Conditions</h1>
      <div className="mt-6 space-y-4 text-sm leading-relaxed text-slate-300">
        <p>
          By using FF ID Bazaar you agree to deal only through the platform. No direct
          contact between buyer and seller is allowed. Direct contact may result in a
          permanent ban.
        </p>
        <p>
          All deals are handled under admin supervision. Buyers must pay through the Pay Now
          option only. Sellers receive payment after the secure transfer window.
        </p>
        <p>
          FF ID Bazaar reserves the right to update these terms at any time to keep the
          marketplace safe for everyone.
        </p>
      </div>
    </main>
  );
}
