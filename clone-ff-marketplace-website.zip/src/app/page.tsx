import Link from "next/link";
import AccountCard from "@/components/AccountCard";
import { getAllAccounts } from "@/lib/accounts";
import Testimonials from "@/components/Testimonials";
import Faq from "@/components/Faq";

export const dynamic = "force-dynamic";

const steps = [
  "Users can list their Free Fire account by providing complete and accurate details to attract interested buyers.",
  "Buyers can contact you through chat, where you can discuss and finalize the deal.",
  "Once agreed, under admin supervision, you securely share the account details.",
  "The buyer completes the payment, and the account is successfully sold.",
];

const features = [
  {
    icon: "🔒",
    title: "Admin-Protected Transfers",
    desc: "Every deal is handled under admin supervision. Your payment is confirmed first — account details are only shared once payment is locked in. No scams, no back-outs.",
  },
  {
    icon: "⭐",
    title: "Verified Seller Ratings",
    desc: "Check seller ratings and reviews before you buy. Every seller on FF ID Bazaar has a public track record — you always know exactly who you're dealing with.",
  },
  {
    icon: "🎮",
    title: "All Budget Ranges",
    desc: "Find Free Fire accounts from Level 1 to Level 100+ across every price range. Whether you want a starter account or a high-rank diamond account, it's all here.",
  },
  {
    icon: "💬",
    title: "Chat Before You Buy",
    desc: "Talk to the seller directly before committing. Ask about skins, diamonds, rank, or any detail — confirm everything inside the platform before a single rupee changes hands.",
  },
];

export default async function HomePage() {
  const accounts = await getAllAccounts();

  return (
    <main>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="container-ff grid items-center gap-8 py-14 md:grid-cols-2 md:py-20">
          <div>
            <span className="inline-block rounded-full border border-[#ffba00]/40 bg-[#ffba00]/10 px-4 py-1 text-xs font-bold uppercase tracking-wider text-gold">
              Account Marketplace
            </span>
            <h1 className="mt-5 text-4xl font-black leading-tight md:text-6xl">
              Buy Free Fire <br />
              Account on <span className="text-gold">FF ID Bazaar</span>
            </h1>
            <p className="mt-5 max-w-lg text-slate-300">
              World&apos;s most trusted place to buy Free Fire account — verified sellers,
              secure admin-protected transfers and a safe payment process.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link href="/account-list" className="btn-gold px-6 py-3 text-sm">
                Browse Accounts
              </Link>
              <Link
                href="/#how-we-work"
                className="rounded-full border border-white/15 px-6 py-3 text-sm font-semibold hover:border-gold hover:text-gold"
              >
                How We Work
              </Link>
            </div>
            <div className="mt-8 flex gap-8 text-sm">
              <div>
                <div className="text-2xl font-black text-gold">750+</div>
                <div className="text-slate-400">Accounts Listed</div>
              </div>
              <div>
                <div className="text-2xl font-black text-gold">100%</div>
                <div className="text-slate-400">Admin Protected</div>
              </div>
              <div>
                <div className="text-2xl font-black text-gold">4.8★</div>
                <div className="text-slate-400">Avg Rating</div>
              </div>
            </div>
          </div>
          <div className="relative">
            <div className="gold-ring rounded-3xl bg-gradient-to-br from-[#171b27] to-[#1e2333] p-6">
              <div className="text-sm font-bold uppercase tracking-wider text-gold">
                Featured Account
              </div>
              {accounts[0] ? (
                <div className="mt-4">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={accounts[0].images[0]}
                    alt="Featured Free Fire account"
                    className="aspect-video w-full rounded-xl object-cover"
                  />
                  <div className="mt-4 flex items-center justify-between">
                    <span className="text-lg font-bold">LV {accounts[0].level}</span>
                    <span className="rounded-lg bg-[#ffba00] px-3 py-1 font-extrabold text-[#1a1203]">
                      ₹{accounts[0].price.toLocaleString("en-IN")}
                    </span>
                  </div>
                </div>
              ) : null}
            </div>
          </div>
        </div>
      </section>

      {/* Latest Accounts */}
      <section className="container-ff py-10">
        <div className="mb-6 flex items-end justify-between">
          <div>
            <h2 className="text-2xl font-black md:text-3xl">Latest Accounts</h2>
            <p className="text-sm text-slate-400">
              India&apos;s Trusted FF Account Store
            </p>
          </div>
          <Link href="/account-list" className="text-sm font-semibold text-gold hover:underline">
            View all →
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          {accounts.map((acc) => (
            <AccountCard key={acc.id} account={acc} />
          ))}
        </div>
      </section>

      {/* How We Work */}
      <section id="how-we-work" className="container-ff py-14">
        <h2 className="text-center text-2xl font-black md:text-3xl">How We Work</h2>
        <div className="mx-auto mt-2 h-1 w-20 rounded bg-[#ffba00]" />
        <div className="mt-10 grid gap-5 md:grid-cols-4">
          {steps.map((s, i) => (
            <div key={i} className="card-ff p-6">
              <div className="grid h-12 w-12 place-items-center rounded-full bg-[#ffba00] text-xl font-black text-[#1a1203]">
                {i + 1}
              </div>
              <p className="mt-4 text-sm text-slate-300">{s}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Why choose */}
      <section className="container-ff py-10">
        <p className="mx-auto max-w-3xl text-center text-slate-300">
          Thousands of Free Fire players choose FF ID Bazaar every month to buy free fire
          account — here&apos;s what makes us different.
        </p>
        <div className="mt-10 grid gap-5 md:grid-cols-4">
          {features.map((f) => (
            <div key={f.title} className="card-ff p-6">
              <div className="text-3xl">{f.icon}</div>
              <h3 className="mt-3 font-bold text-gold">{f.title}</h3>
              <p className="mt-2 text-sm text-slate-400">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA cards */}
      <section className="container-ff grid gap-5 py-10 md:grid-cols-2">
        <div className="gold-ring rounded-2xl bg-gradient-to-br from-[#171b27] to-[#1e2333] p-8">
          <h3 className="text-xl font-black">Start Selling Your Account</h3>
          <p className="mt-3 text-sm text-slate-300">
            Ready to sell your account? Create your listing in just a few steps and reach
            interested buyers instantly. Start now and turn your account into real value.
          </p>
          <Link href="/account-list" className="btn-gold mt-5 inline-block px-5 py-2.5 text-sm">
            Sell Account
          </Link>
        </div>
        <div className="gold-ring rounded-2xl bg-gradient-to-br from-[#171b27] to-[#1e2333] p-8">
          <h3 className="text-xl font-black">Chat With Admin</h3>
          <p className="mt-3 text-sm text-slate-300">
            Need help or have any questions? Connect with our admin for quick support and
            guidance. We&apos;re here to ensure your buying and selling experience is safe
            and smooth.
          </p>
          <Link
            href="/account-list"
            className="mt-5 inline-block rounded-full border border-white/15 px-5 py-2.5 text-sm font-semibold hover:border-gold hover:text-gold"
          >
            Chat with Admin
          </Link>
        </div>
      </section>

      <Testimonials />
      <Faq />
    </main>
  );
}
