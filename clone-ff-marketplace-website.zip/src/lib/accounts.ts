import { db } from "@/db";
import { accounts, type Account } from "@/db/schema";
import { eq, ne, and } from "drizzle-orm";

export async function getAllAccounts(): Promise<Account[]> {
  return db.select().from(accounts).orderBy(accounts.id);
}

export async function getAccount(id: number): Promise<Account | undefined> {
  const rows = await db.select().from(accounts).where(eq(accounts.id, id)).limit(1);
  return rows[0];
}

export async function getRelatedAccounts(id: number, limit = 8): Promise<Account[]> {
  return db
    .select()
    .from(accounts)
    .where(and(ne(accounts.id, id)))
    .limit(limit);
}

export function formatINR(value: number): string {
  return "₹" + value.toLocaleString("en-IN");
}
