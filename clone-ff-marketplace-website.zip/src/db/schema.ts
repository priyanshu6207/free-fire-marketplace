import { pgTable, serial, integer, text, jsonb, numeric } from "drizzle-orm/pg-core";

export const accounts = pgTable("accounts", {
  id: serial("id").primaryKey(),
  level: integer("level").notNull(),
  price: integer("price").notNull(),
  accId: text("acc_id").notNull(),
  country: text("country").notNull().default("IND"),
  server: text("server").notNull().default("India (IND)"),
  loginWith: text("login_with").notNull().default("Google"),
  sellerName: text("seller_name").notNull(),
  sellerAvatar: text("seller_avatar"),
  sellerRating: numeric("seller_rating").notNull().default("0"),
  sellerReviews: integer("seller_reviews").notNull().default(0),
  memberSince: text("member_since").notNull().default("Sep 2026"),
  images: jsonb("images").$type<string[]>().notNull().default([]),
});

export type Account = typeof accounts.$inferSelect;
