import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import { sql } from "drizzle-orm";
import { accounts } from "../src/db/schema";
import { seedAccounts } from "../src/db/seed-data";

async function main() {
  const databaseUrl =
    process.env.DATABASE_URL ??
    "postgresql://postgres:postgres@127.0.0.1:5432/app_db";
  const pool = new Pool({ connectionString: databaseUrl });
  const db = drizzle(pool);

  await db.execute(sql`truncate table ${accounts} restart identity`);

  for (const a of seedAccounts) {
    await db.insert(accounts).values({
      level: a.level,
      price: a.price,
      accId: a.accId,
      country: "IND",
      server: "India (IND)",
      loginWith: a.loginWith,
      sellerName: a.sellerName,
      sellerAvatar: a.sellerAvatar,
      sellerRating: a.sellerRating,
      sellerReviews: a.sellerReviews,
      memberSince: a.memberSince,
      images: a.images,
    });
  }

  const count = await db.select().from(accounts);
  console.log(`Seeded ${count.length} accounts.`);
  await pool.end();
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
